﻿using Glazki_Save_App.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Glazki_Save_App.Utils
{
    internal class DatabaseContext
    {
        public static ModelDB db = new ModelDB();
    }
}
